/**
 * Example to perform keyword search on investigations using ICAT API.
 * 
 * @author Richard Tyer
 */
package icatpresentation;

import java.util.Arrays;
import java.util.List;
import uk.icat3.client.*;

public class KeywordSearch {

    private final static String[] keywordArray = {"lmo"};

    public static void main(String[] args) {
        String username = AuthDetails.getInstance().getUsername();
        String password = AuthDetails.getInstance().getPassword();
        ICATService service = new ICATService();
        ICAT icat = service.getICATPort();

        try {
            String sid = icat.login(username, password);

            List<String> keywordList = Arrays.asList(keywordArray);
            List<Investigation> investigations = icat.searchByKeywords(sid,
                    keywordList);
                        
            for (Investigation inv : investigations) {
                long id = inv.getId();
                String title = inv.getTitle();
                System.out.println("Investigation " + id + " title: " + title);
            }
        } catch (Exception e) {
            System.err.println(e);
        }
    }
}
