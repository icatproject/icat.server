/**
 * Example to perform retrieve all keywords from search on 
 * investigations using ICAT API.
 * 
 * @author Richard Tyer
 */
package icatpresentation;

import java.util.List;
import uk.icat3.client.*;

public class KeywordDisplay {

    private final static String[] keywordArray = {"HRPD", "LMO"};

    public static void main(String[] args) {
        String username = AuthDetails.getInstance().getUsername();
        String password = AuthDetails.getInstance().getPassword();

        ICATService service = new ICATService();
        ICAT icat = service.getICATPort();

        try {
            String sid = icat.login(username, password);

            KeywordDetails kd = new KeywordDetails();
            for (String kw : keywordArray) {
                kd.getKeywords().add(kw);
            }

            kd.setInvestigationInclude(InvestigationInclude.KEYWORDS_ONLY);
            List<Investigation> investigations = icat.searchByKeywordsAll(sid,
                    kd, 0, 200);

            for (Investigation inv : investigations) {
                long id = inv.getId();

                String title = inv.getTitle();
                System.out.println("Investigation: " + id + " has title " +
                        title);

                if (inv.getKeywordCollection().size() > 0) {
                    for (Keyword kw : inv.getKeywordCollection()) {
                        System.out.println("\t" + kw.getKeywordPK().getName());
                    }
                } else {
                    System.out.println("Investigation no keywords?");
                }

            }
        } catch (Exception e) {
            System.err.println(e);
        }
    }
}

