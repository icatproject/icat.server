/**
 * Example to show user authentication with ICAT API to get SID
 * 
 * @author Richard Tyer
 */
package icatpresentation;

import uk.icat3.client.*;


public class Authenticate {
    
    public static void main(String []args) {
        String username = AuthDetails.getInstance().getUsername();
        String password = AuthDetails.getInstance().getPassword();
        
        ICATService service = new ICATService();
        ICAT icat = service.getICATPort();
        
        try {
            String sid = icat.login(username, password);
            System.out.println("Session ID = " + sid);            
            icat.logout(sid);
        } catch (Exception e) {
            System.err.println(e);
        }
    }
}
