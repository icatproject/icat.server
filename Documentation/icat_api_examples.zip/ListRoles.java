/**
 * Example to list authorisation roles valid within the ICAT
 * 
 * @author Richard Tyer
 */
package icatpresentation;

import uk.icat3.client.*;

public class ListRoles {

    public static void main(String[] args) {

        String username = AuthDetails.getInstance().getUsername();
        String password = AuthDetails.getInstance().getPassword();

        ICATService service = new ICATService();
        ICAT icat = service.getICATPort();

        try {
            String sid = icat.login(username, password);

            for (IcatRole role : icat.listRoles(sid)) {
                System.out.println("---> " + role.getRole());
            }

        } catch (Exception e) {
            System.err.println(e);
        }
    }
}
