/**
 * Example to perform case sensitive keyword search on investigations
 * using ICAT API.
 * 
 * @author Richard Tyer
 */
package icatpresentation;

import java.util.List;
import uk.icat3.client.*;


public class CaseSensitiveKeywordSearch {
    private final static String[] keywordArray = {"HRPD", "lmo"};

    public static void main(String[] args) {
        String username = AuthDetails.getInstance().getUsername();
        String password = AuthDetails.getInstance().getPassword();

        ICATService service = new ICATService();
        ICAT icat = service.getICATPort();

        try {
            String sid = icat.login(username, password);

            KeywordDetails kd = new KeywordDetails();
            List<String> kwList = kd.getKeywords();
            
            for (String kw : keywordArray) {
                kwList.add(kw);
            }
         
            kd.setCaseSensitive(false);
            kd.setInvestigationInclude(InvestigationInclude.KEYWORDS_ONLY);
            List<Investigation> investigations =
                    icat.searchByKeywordsAll(sid, kd, 0, 200);

            for (Investigation inv : investigations) {                               
                long id = inv.getId();
                String title = inv.getTitle();
                System.out.println("Investigation - ID: " + id + "\tTitle: " 
                                    + title);

                if (inv.getKeywordCollection().size() > 0) {
                    System.out.println("Investigation has keywords!");
                }
            }
        } catch (Exception e) {
            System.err.println(e);
        }
    }
}
