/**
 * Example to demonstrate retrieving an investigation and drilling 
 * down into its constituent datasets and datafiles
 * 
 * @author Richard Tyer
 */
package icatpresentation;

import uk.icat3.client.*;

public class DrillDown {

    private final static long investigationID = 3906738L;

    public static void main(String[] args) {
        String username = AuthDetails.getInstance().getUsername();
        String password = AuthDetails.getInstance().getPassword();

        ICATService service = new ICATService();
        ICAT icat = service.getICATPort();

        try {
            String sid = icat.login(username, password);

            Investigation inv = icat.getInvestigationIncludes(sid,
                    investigationID,
                    InvestigationInclude.DATASETS_AND_DATAFILES);

            for (Dataset dataset : inv.getDatasetCollection()) {
                Long dsID = dataset.getId();
                String dsName = dataset.getName();

                System.out.println("Dataset: " + dsID + " has name " + dsName);

                for (Datafile datafile : dataset.getDatafileCollection()) {
                    long dfID = datafile.getId();
                    String dfName = datafile.getName();

                    System.out.println("Datafile: " + dfName + " has name " +
                            dfID);
                }
            }
        } catch (Exception e) {
            System.err.println(e);
        }
    }
}
