/**
 * Example to get URLs from ICAT API in order to download data files
 * 
 * @author Richard Tyer
 */
package icatpresentation;

import uk.icat3.client.*;

public class GetURLForDownload {
    private final static long datasetID = 15067493L;
    private final static long datafileID = 3908539L;

    public static void main(String[] args) {
        String username = AuthDetails.getInstance().getUsername();
        String password = AuthDetails.getInstance().getPassword();

        ICATService service = new ICATService();
        ICAT icat = service.getICATPort();

        try {
            String sid = icat.login(username, password);

            String dfURL = icat.downloadDatafile(sid, datafileID);
            System.out.println("URL for datafile " + dfURL);

            String dsURL = icat.downloadDataset(sid, datasetID);
            System.out.println("URL for dataset " + dsURL);
        } catch (Exception e) {
            System.err.println(e);
        }
    }
}
