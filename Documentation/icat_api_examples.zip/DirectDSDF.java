/**
 * Example to show retrieval of datasets and datafiles directly, i.e. 
 * without getting parent investigations first
 * 
 * @author Richard Tyer
 */
package icatpresentation;

import uk.icat3.client.*;

public class DirectDSDF {
    private final static long datasetID = 15067493L;

    public static void main(String[] args) {
        String username = AuthDetails.getInstance().getUsername();
        String password = AuthDetails.getInstance().getPassword();

        ICATService service = new ICATService();
        ICAT icat = service.getICATPort();

        try {
            String sid = icat.login(username, password);
            Dataset dataset = icat.getDatasetIncludes(sid, datasetID, DatasetInclude.DATASET_AND_DATAFILES_ONLY);
            System.out.println("Dataset name: " + dataset.getName() );
          
            if (dataset.getDatafileCollection().size() > 0) {
                for (Datafile df : dataset.getDatafileCollection()) {
                    System.out.println("---> Data file ID " + df.getId());
                }
            } else {
                System.out.println("Dataset has no datafiles?");
            }
        } catch (Exception e) {
            System.err.println(e);
        }
    }
}
