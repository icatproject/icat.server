/**
 * Singleton encapsulating federal id and password for use in ICAT API
 * client classes
 * 
 * @author Richard Tyer
 */
package icatpresentation;


public class AuthDetails {
    private final static String username=System.getProperty("user.fedid");
    private final static String password=System.getProperty("user.password");
    
    private static AuthDetails authDetails;
    
    private AuthDetails() {
    }
    
    public static AuthDetails getInstance() {
        if (authDetails==null) {
            authDetails = new AuthDetails();
        }
        
        return authDetails;
    }
    
    public String getUsername() {
        return username;
    }
    
    public String getPassword() {
        return password;
    }
}
